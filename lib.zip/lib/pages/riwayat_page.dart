import 'package:flutter/material.dart';
import '../models/transaksi.dart';
import '../widgets/custom_appbar.dart';

class RiwayatPage extends StatelessWidget {
  final List<Transaksi> riwayat;

  const RiwayatPage({super.key, required this.riwayat});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
  title: "Riwayat",
  icon: Icons.history,
),
      body: ListView.builder(
        itemCount: riwayat.length,
        itemBuilder: (context, index) {
          final data = riwayat[index];

          return Card(
            child: ListTile(
              title: Text("${data.namaGame} - ${data.jumlah}"),
              subtitle: Text(
                  "ID: ${data.idPlayer}\nEmail: ${data.email}"),
            ),
          );
        },
      ),
    );
  }
}