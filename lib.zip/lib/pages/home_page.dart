import 'package:flutter/material.dart';
import '../models/game.dart';
import '../models/transaksi.dart';
import 'form_topup_page.dart';
import '../widgets/custom_appbar.dart';


class HomePage extends StatelessWidget {
  final List<Game> games;
  final Function(Transaksi) onTopUp;

  const HomePage({
    super.key,
    required this.games,
    required this.onTopUp,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const CustomAppBar(
  title: "Pilih Game",
  icon: Icons.games,
),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        itemCount: games.length,
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          crossAxisSpacing: 16,
          mainAxisSpacing: 16,
        ),
        itemBuilder: (context, index) {
          final game = games[index];

          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => FormTopUpPage(
                    game: game,
                    onSubmit: onTopUp,
                  ),
                ),
              );
            },
            child: Card(
              elevation: 5,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Image.asset(game.logo, height: 60),
                  const SizedBox(height: 10),
                  Text(
                    game.nama,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}