import 'package:flutter/material.dart';
import '../models/game.dart';
import '../models/transaksi.dart';
import 'home_page.dart';
import 'inventory_page.dart';
import 'riwayat_page.dart';


class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  int _selectedIndex = 0;

  List<Game> games = [
    Game(nama: "Mobile Legends", logo: "assets/images/ml.png", stok: 5000),
    Game(nama: "Free Fire", logo: "assets/images/ff.png", stok: 3000),
    Game(nama: "PUBG Mobile", logo: "assets/images/pubg.png", stok: 2000),
  ];

  List<Transaksi> riwayat = [];

  void tambahTransaksi(Transaksi transaksi) {
    setState(() {
      riwayat.add(transaksi);
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(games: games, onTopUp: tambahTransaksi),
      InventoryPage(games: games),
      RiwayatPage(riwayat: riwayat),
    ];

    return Scaffold(
      body: pages[_selectedIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.home), label: "Home"),
          BottomNavigationBarItem(
              icon: Icon(Icons.inventory), label: "Inventory"),
          BottomNavigationBarItem(
              icon: Icon(Icons.history), label: "Riwayat"),
        ],
      ),
    );
  }
}