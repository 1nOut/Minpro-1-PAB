import 'package:flutter/material.dart';
import '../models/game.dart';
import '../models/transaksi.dart';

class FormTopUpPage extends StatefulWidget {
  final Game game;
  final Function(Transaksi) onSubmit;

  const FormTopUpPage({
    super.key,
    required this.game,
    required this.onSubmit,
  });

  @override
  State<FormTopUpPage> createState() => _FormTopUpPageState();
}

class _FormTopUpPageState extends State<FormTopUpPage> {
  final idController = TextEditingController();
  final jumlahController = TextEditingController();
  final emailController = TextEditingController();

  void kirim() {
    int jumlah = int.tryParse(jumlahController.text) ?? 0;

    if (jumlah > widget.game.stok) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("Stok tidak cukup!")),
      );
      return;
    }

    widget.game.stok -= jumlah;

    widget.onSubmit(
      Transaksi(
        namaGame: widget.game.nama,
        idPlayer: idController.text,
        jumlah: jumlah,
        email: emailController.text,
      ),
    );

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text("Top Up Berhasil!")),
    );

    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar:
          AppBar(title: Text("Top Up ${widget.game.nama}")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            TextField(
              controller: idController,
              decoration:
                  const InputDecoration(labelText: "ID Player"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: jumlahController,
              keyboardType: TextInputType.number,
              decoration:
                  const InputDecoration(labelText: "Jumlah Top Up"),
            ),
            const SizedBox(height: 10),
            TextField(
              controller: emailController,
              decoration:
                  const InputDecoration(labelText: "Email"),
            ),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: kirim,
              child: const Text("Kirim"),
            ),
          ],
        ),
      ),
    );
  }
}