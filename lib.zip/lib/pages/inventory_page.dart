import 'package:flutter/material.dart';
import '../models/game.dart';
import '../widgets/custom_appbar.dart';

class InventoryPage extends StatefulWidget {
  final List<Game> games;

  const InventoryPage({super.key, required this.games});

  @override
  State<InventoryPage> createState() => _InventoryPageState();
}

class _InventoryPageState extends State<InventoryPage> {
  void tambahStokDialog() {
    Game? selectedGame;
    final jumlahController = TextEditingController();

    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text("Tambah Stok"),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              DropdownButtonFormField<Game>(
                hint: const Text("Pilih Game"),
                items: widget.games.map((game) {
                  return DropdownMenuItem(
                    value: game,
                    child: Text(game.nama),
                  );
                }).toList(),
                onChanged: (value) {
                  selectedGame = value;
                },
              ),
              const SizedBox(height: 10),
              TextField(
                controller: jumlahController,
                keyboardType: TextInputType.number,
                decoration:
                    const InputDecoration(labelText: "Jumlah Stok"),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text("Batal"),
            ),
            ElevatedButton(
              onPressed: () {
                if (selectedGame != null) {
                  int jumlah =
                      int.tryParse(jumlahController.text) ?? 0;

                  setState(() {
                    selectedGame!.stok += jumlah;
                  });

                  Navigator.pop(context);
                }
              },
              child: const Text("Tambah"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: "Inventory",
        icon: Icons.inventory,
      ),
      floatingActionButtonLocation:
          FloatingActionButtonLocation.startTop,
      floatingActionButton: Padding(
        padding: const EdgeInsets.only(top: 10),
        child: FloatingActionButton(
          mini: true,
          backgroundColor: const Color(0xFF145A32),
          onPressed: tambahStokDialog,
          child: const Icon(Icons.add),
        ),
      ),
      body: ListView.builder(
        itemCount: widget.games.length,
        itemBuilder: (context, index) {
          final game = widget.games[index];

          return Card(
            margin:
                const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: ListTile(
              leading: Image.asset(game.logo, width: 40),
              title: Text(game.nama),
              subtitle: Text("Stok: ${game.stok}"),
            ),
          );
        },
      ),
    );
  }
}