class Transaksi {
  String namaGame;
  String idPlayer;
  int jumlah;
  String email;

  Transaksi({
    required this.namaGame,
    required this.idPlayer,
    required this.jumlah,
    required this.email,
  });
}