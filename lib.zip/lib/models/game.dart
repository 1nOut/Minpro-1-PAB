class Game {
  String nama;
  String logo;
  int stok;

  Game({
    required this.nama,
    required this.logo,
    required this.stok,
  });
}